package com.example.library.model;

public class Magazine extends MediaItem {
    public Magazine(String title, int copiesAvailable) {
        super(title, copiesAvailable);
    }
}
