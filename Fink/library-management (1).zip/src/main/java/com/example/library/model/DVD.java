package com.example.library.model;

public class DVD extends MediaItem {
    public DVD(String title, int copiesAvailable) {
        super(title, copiesAvailable);
    }
}
